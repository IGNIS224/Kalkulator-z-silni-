﻿using System;

namespace Calculator.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Witaj w aplikacji KALKULATOR!");

            while (true)
            {
                try
                {
                    Console.WriteLine("Podaj proszę 1 liczbę:");
                    var number1 = GetInput();

                    Console.WriteLine("Jaką operację chcesz wykonać? Możliwe operacje to: '+', '-', '*', '/', '!'.");
                    var operation = Console.ReadLine();

                    if (operation == "!")
                    {
                        if (number1 < 0)
                        {
                            throw new Exception("Nie można obliczyć silni z liczby ujemnej.\n");
                        }
                        double result = CalculateFactorial((int)number1);
                        Console.WriteLine($"Silnia z {number1} wynosi: {result}.\n");
                    }
                    else
                    {
                        Console.WriteLine("Podaj proszę 2 liczbę:");
                        var number2 = GetInput();
                        double result = Calculator.Calculate(number1, number2, operation);
                        Console.WriteLine($"Wynik Twojego działania to: {Math.Round(result, 2)}.\n");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log(ex.Message);
                }
            }
        }

        private static double CalculateFactorial(int number)
        {
            if (number == 0)
                return 1;

            double result = 1;
            for (int i = 1; i <= number; i++)
            {
                result *= i;
            }
            return result;
        }

        private static double GetInput()
        {
            if (!double.TryParse(Console.ReadLine(), out double input))
                throw new Exception("Podana wartość nie jest liczbą.\n");

            return input;
        }
    }

    public class Logger
    {
        public static void Log(string message)
        {
            // Tutaj możesz zaimplementować logowanie do pliku lub inny mechanizm logowania.
            // Na potrzeby przykładu, wypisujemy komunikat na konsoli.
            Console.WriteLine("Błąd: " + message);
        }
    }

    public class Calculator
    {
        public static double Calculate(double number1, double number2, string operation)
        {
            switch (operation)
            {
                case "+":
                    return number1 + number2;
                case "-":
                    return number1 - number2;
                case "*":
                    return number1 * number2;
                case "/":
                    if (number2 == 0)
                        throw new Exception("Nie można dzielić przez zero.\n");
                    return number1 / number2;
                default:
                    throw new Exception("Wybrałeś złą operację!\n");
            }
        }
    }
}
